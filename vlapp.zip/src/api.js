import axios from "axios";
import { db } from "./firebase";
import { collection, getDocs, doc, setDoc, query, where, limit, deleteDoc, orderBy } from "firebase/firestore";

export const createNew = (rectype) => {
  let random = Math.random()*100;
  let fid = rectype+'_'+new Date().getTime()+'_'+random;
  return {rectype: rectype, fid: fid, user: localStorage.getItem('loggedInUser')};
}
export const getProfile = async() => {
  const username = localStorage.getItem('loggedInUser');
  const oldcache = localStorage.getItem('cache') || {};
  const ret = oldcache.userobj || await aquery('users', [{field: 'username', op: '==', value: username}]);
  localStorage.setItem('cache', {...oldcache, userobj: ret});
  if (ret) return ret;
}

export const togglePassword = (show, setShow) => {
  setShow(!show);
}

export const addSaveRecipe = async (recipe) => {
  if (recipe._id) {
    recipe.id = recipe._id;
    delete recipe._id;
  }
  if (recipe.id) {
    await setDoc(doc(db, "recipes", recipe.id), recipe, { merge: true });
    return recipe.id;
  } else {
    const q = query(collection(db, "recipes"), where("name", "==", recipe.name));
    const snapshot = await getDocs(q);
    if (!snapshot.empty) {
      const id = snapshot.docs[0].id;
      await setDoc(doc(db, "recipes", id), recipe, { merge: true });
      return id;
    } else {
      const newDoc = doc(collection(db, "recipes"));
      await setDoc(newDoc, recipe);
      return newDoc.id;
    }
  }
};

export const aquery = async (coll, conditions = [], options = {}) => {
  const colRef = collection(db, coll);
  var qRef = colRef;

  if (conditions.length > 0) {
    conditions.forEach((cond) => {
      if (!cond.op) cond.op = '==';
      qRef = query(qRef, where(cond.field, cond.op, cond.value));
    })
  }

  if (options.orderBy) {
    if (!options.orderDir) options.orderDir = 'asc';
    qRef = query(qRef, orderBy(options.orderBy, options.orderDir));
  }

  if (options.limit) {
    qRef = query(qRef, limit(options.limit));
  }

  var snapshot = await getDocs(qRef);
  return snapshot.docs.map(doc => ({id: doc.id, ...doc.data()}));
}

export const deleteRec = async (rec) => {
  const q = query(collection(db, rec.rectype), where('fid', '==', rec.fid), limit(1));
  var snapshot = await getDocs(q);
  if (!snapshot.empty) {
    const doc = snapshot.docs[0];
    try {
      await deleteDoc(doc.ref);
      console.log('Deleted successfully: ' + (doc.data().fid || doc.id));
      return {result: 'ok'};
    } catch (err) {
      console.error('Error while deleting doc: ' + (doc.data().fid || doc.id), err);
    }
    return {result: 'ko'};
  } else {
    console.warn('Doc not found ', rec.fid);
    return {result: 'ko'};
  }
}

export const saveRec = async (rec) => {
  const rectype = rec.rectype;
  const now = new Date();
  if (rec._id) {
    rec.id = rec._id;
    delete rec._id;
  }
  try {
    if (rec.id) {
        rec._upd = now.getTime();
      await setDoc(doc(db, rectype, rec.id), rec, { merge: true });
      return rec.id;
    } else if (rec.fid) {
      const q = query(collection(db, rectype), where("fid", "==", rec.fid));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const id = snapshot.docs[0].id;
        rec._upd = now.getTime();
        await setDoc(doc(db, rectype, id), rec, { merge: true });
        return id;
      } else {
        const newDoc = doc(collection(db, rectype));
        newDoc._ins = now.getTime();
        newDoc._upd = now.getTime();
        await setDoc(newDoc, rec);
        return newDoc.id;
      }
    } else {
      console.error('Error while saving '+rec.id+' | rec.fid not found');
      return undefined;
    }
  } catch (error) {
    console.error('Error while saving '+rec.id+' | '+error);
    return undefined;
  }
};