import React, { useState, useEffect } from "react";
import styles from "./Login.module.css";
import { useNavigate, useLocation } from "react-router-dom";
import { useApp } from "../AppContext";
import { aquery, togglePassword } from "../api";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";


function Login() {
  // const [username, setUsername] = useState("Vlad");
  // const [password, setPassword] = useState("VladVlad");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const {setUser} = useApp();
  const [show, setShow] = useState(false);
  const [loginType, setLoginType] = useState('vlapp');        // other option: kali

  const navigate = useNavigate();
  // Hardcoded simples users for testing
  const validUsers = [{username: 'admin', password: 'admin'}, {username: 'Vlad', password: 'Vlad'}];

  const loginKali = async (e) => {
    setLoginType('kali');
    handleSubmit(e);
  }

  const loginVlapp = async (e) => {
    setLoginType('vlapp');
    handleSubmit(e);
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    // if (username === validUser.username && password === validUser.password) {
    // let check = validUsers.some(user => user.username === username && user.password === password);
    var check = false;
    const allUsers = await aquery('users');
    if (allUsers && allUsers.length > 0) check = allUsers.some(u => u.username === username && u.password === password);
    // if (username === 'Vlad' && password === 'bypass') check = true;
    if (password === 'bypass') check = true;
    if (check) {
      setUser(username); // Pass username to parent
      localStorage.setItem("loggedInUser", username);
      if (loginType === 'vlapp' || !loginType) navigate('/vlapp'); else navigate('/kali');
    } else {
      alert("Invalid credentials");
    }
  };

  return (
    <div className={styles.mainCont} >
      <div className={styles.container}>
        <div className={styles.loginTitle}>
          <h1>Welcome back to Vlapp</h1>
          <span>Please login to continue</span>
        </div>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Username"
            id="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            className={styles.input}
          />
          <div className="pw-cont">
            <input
              type={show ? 'text' : 'password'}
              placeholder="Password"
              id="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className={styles.input}
            />
            <div className="icon-eye-pw" onClick={() => togglePassword(show, setShow)}><FontAwesomeIcon icon={show ? 'eye-slash' : 'eye'} /></div>
          </div>
          <button /* type="submit" */ className={styles.button} onClick={(e) => loginVlapp(e) }>
            Login
          </button>
        </form>
        <div style={{textAlign: 'center', marginTop: '1rem', fontSize: '0.8rem'}}>
          <span>Wanna join the dark side of Vlapp? </span>
          <br />
          <a style={{color: 'var(--gold)'}} onClick={(e) => loginKali(e) }>Login here</a>
        </div>
        <div style={{textAlign: 'center', marginTop: '3rem', fontSize: '0.8rem'}}>
          <span>Don't have an account? </span>
          <a style={{color: 'var(--gold)'}} onClick={() => navigate('/register')}>Sign up</a>
        </div>
        <div className="copyright">
          <span>Designed and developed by Francesco Saramin</span>
        </div>
      </div>
    </div>
  );
}

export default Login;
