import { useEffect, useState } from "react";
import { aquery, saveRec, togglePassword } from "../../api";
import InlineEdit from "../../components/InlineEdit";
import Sidebar from "../../components/Sidebar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function Profile() {
    const username = localStorage.getItem('loggedInUser');
    const [profile, setProfile] = useState(null);
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [changingPw, setChangingPw] = useState(false);
    const [show, setShow] = useState(false);
    const [showcp, setShowcp] = useState(false);

    useEffect(() => {
        async function getUser(){
            const ret = await aquery('users', [{field: 'username', op: '==', value: username}]);
            if (ret && ret.length > 0) setProfile(ret[0]);
        }
        getUser();
    }, []);

    const updateProfile = (field, val) => {
        setProfile((prev) => ({...prev, [field]: val}))
    }
    const confirmChangePassword = async () => {
        if (newPassword && confirmPassword && newPassword === confirmPassword) {
            const ok = window.confirm('You are about to change the password. You will have to use the new password for login the next time. This action will automatically save your profile. Confirm?');
            if (!ok) return;
            // updateProfile('password', newPassword);
            const updated = { ...profile, password: newPassword };
            setProfile(updated);
            const ret = await saveRec(updated);
            if (ret) alert('Your profile has been saved correctly'); else alert('An error occurred while saving your profile, please try again later');
        } else {
            alert('Password and confirm password don\'t match, no changes are applied');
        }
    }
    const saveProfile = async () => {
        const ret = await saveRec(profile);
        if (ret) alert('Your profile has been saved correctly'); else alert('An error occurred while saving your profile, please try again later');
    }
    return (
        <div className="profile-cont">
            <Sidebar />
            <div className="profile-title">
                <h2><p>Profile</p></h2>
            </div>
            <div className="profile-body">
                <div className="pro-input-cont">
                    <span>Username (not editable)</span><br />
                    {/* <InlineEdit value={profile?.username || ''} onChange={updateProfile} parms={{field: 'username', type: 'text'}}/> */}
                    <span>{profile?.username || ''}</span>
                    {/* <input type='text' value={profile?.username || ''} onChange={updateProfile} className="input"/> */}
                    <hr className="profile-hr"/>
                </div>
                {/* <div className="pro-input-cont">
                    <span className="password">Edit password</span><br />
                    <InlineEdit value={profile?.password || ''} onChange={updateProfile} parms={{field: 'password', type: 'text'}}/>
                    <hr className="profile-hr"/>
                </div> */}
                <div className="pro-input-cont">
                    <span>Edit Full name</span><br />
                    <InlineEdit value={profile?.fullname || profile?.username || ''} onChange={updateProfile} parms={{field: 'fullname', type: 'text'}}/>
                    <hr className="profile-hr"/>
                </div>
                <div className="pro-change-pw">
                    <span>Change password</span>
                    {changingPw ? <div className="change-pw-sec">
                        <div className="pw-cont">
                            <input
                            type={show ? 'text' : 'password'}
                            placeholder="Password"
                            id="Password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            required
                            />
                            <div className="icon-eye-pw" onClick={() => togglePassword(show, setShow)}><FontAwesomeIcon icon={show ? 'eye-slash' : 'eye'} /></div>
                        </div>
                        <div className="pw-cont">
                            <input
                            type={showcp ? 'text' : 'password'}
                            placeholder="Confirm Password"
                            id="ConfirmPassword"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                            />
                            <div className="icon-eye-pw" onClick={() => togglePassword(showcp, setShowcp)}><FontAwesomeIcon icon={showcp ? 'eye-slash' : 'eye'} /></div>
                        </div>
                        <div className="inline-button" onClick={() => confirmChangePassword()}>
                            <div className="btn">CONFIRM NEW PASSWORD</div>
                        </div>
                    </div> 
                    : 
                    <div className="inline-button" onClick={() => setChangingPw(prev => !prev)}>
                        <div className="btn">CHANGE PASSWORD</div>
                    </div>}
                </div>
            </div>
            <div className="profile-bottom bottom-btn" onClick={() => saveProfile()}>
                <div className="btn">SAVE</div>
            </div>
        </div>
    )
}