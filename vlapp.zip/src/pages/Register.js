import React, { useState, useEffect } from "react";
import styles from "./Login.module.css";
import { useNavigate, useLocation } from "react-router-dom";
import { aquery, createNew, saveRec } from "../api";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { togglePassword } from "../api";

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [show, setShow] = useState(false);
  const [showcp, setShowcp] = useState(false);

  const navigate = useNavigate();
  localStorage.removeItem('loggedInUser');
  const handleSubmit = async (e) => {
    e.preventDefault();
    var isValid = true, msg = '';
    if (!username) { isValid = false; msg = 'Please enter a valid username'; }
    else if (!password || password.length < 5) { isValid = false; msg = 'Please enter a password of at least 5 characters'; }
    else if (password !== confirmPassword) { isValid = false; msg = 'Password not confirmed correctly'; } 
    if (!isValid) {
        alert(msg);
        return;
    }
    const res = await aquery('users', [{field: 'username', op: '==', value: username}]);
    if (res.length > 0) {
        // there are other users with the same username
        isValid = false;
        msg = 'This username is already in use, please choose a different one';
    }
    if (!isValid) {
        alert(msg);
        return;
    }
    // create the user
    var newUser = createNew('users');
    newUser.username = username;
    newUser.password = password;
    newUser.fullname = fullName || username;
    const ret = await saveRec(newUser);
    if (ret) {
        alert('Account created correctly, please login as '+newUser.username);
        navigate('/login');
    } else {
        alert('An error occured while trying to create a new account, please retry later');
    }
  };

  return (
    <div className={styles.mainCont} >
      <div className={styles.container}>
        <div className={styles.loginTitle}>
          <h1>Sign up</h1>
          <span>Create an account, choose your username and password</span>
        </div>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Username"
            id="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            className={styles.input}
          />
          <input
            type="text"
            placeholder="Full name"
            id="Fullname"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            // required
            className={styles.input}
          />
          <div className="pw-cont">
            <input
              type={show ? 'text' : 'password'}
              placeholder="Password"
              id="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className={styles.input}
            />
            <div className="icon-eye-pw" onClick={() => togglePassword(show, setShow)}><FontAwesomeIcon icon={show ? 'eye-slash' : 'eye'} /></div>
          </div>
          <div className="pw-cont">
            <input
              type={showcp ? 'text' : 'password'}
              placeholder="Confirm Password"
              id="ConfirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              className={styles.input}
            />
            <div className="icon-eye-pw" onClick={() => togglePassword(showcp, setShowcp)}><FontAwesomeIcon icon={showcp ? 'eye-slash' : 'eye'} /></div>
          </div>
          <button type="submit" className={styles.button}>
            Sign up
          </button>
        </form>
        <div style={{textAlign: 'center', marginTop: '5rem', fontSize: '0.8rem'}}>
          <span>Already have an account? </span>
          <a style={{color: 'var(--gold)'}} onClick={() => navigate('/login')}>Login</a>
        </div>
        <div className="copyright">
          <span>Designed and developed by Francesco Saramin</span>
        </div>
      </div>
    </div>
  );
}

export default Login;
